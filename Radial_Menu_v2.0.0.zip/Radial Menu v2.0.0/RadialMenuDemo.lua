--[[--------------------------------
RADIAL MENU LIBRARY FOR STAND (DEMO)
BY NOWIRY
V2.0.0
-----------------------------------]]

require "RadialMenu" -- Obviusly we need to requiere the library

if filesystem.exists(filesystem.resources_dir() .. "RadialMenuDemo.ytd") then

    -- This lib uses sprites for Option icons.
    -- You can use any of the sprites GTA already has by specifing its dict and name,
    -- you can also register your own .ytd file and use custom textures (the best thing to do I believe).
    -- Use OpenIV to edit and create .ytd files, open the one we're using here to have an example.

	util.register_file(filesystem.resources_dir() .. "RadialMenuDemo.ytd")
else
    error("required file not found: resources/RadialMenu.ytd")
end

gOpenKey = 27 -- scrollwheel

-- First we need to create a new Menu Object using newMenu().
-- It is completly possible to create more than one Menu object with
-- the same open key or not, to be used in different circumstances.

-- Lets create a Menu that opens clicking the scrollwheel:

gMenu = newMenu(gOpenKey)

-- Next we need to add Options to the created Menu using the addOption() method.

gMenu.addOption(Sprite.new("RadialMenuDemo", "fire"), function ()
    local myPos = ENTITY.GET_ENTITY_COORDS(PLAYER.PLAYER_PED_ID())
    FIRE.ADD_EXPLOSION(myPos.x, myPos.y, myPos.z, 0, 1.0, true, false, 0, false)
end)

-- Notice that we used Sprite.new() to pass the icon to addOption(), in other words,
-- icon must be an Sprite instance.

-- addOption returns the optionId of the Option you just added.
-- An optionId is the value that represents a MenuOption in the menu options list and is
-- used in any method that deals with Options.

local optionId = gMenu.addOption(Sprite.new("RadialMenuDemo", "car"))

-- For example, let's set the last Option's callback using its optionId,
-- this is really useful if one wants to change it once we've added the option.

gMenu.setOptionCallback(optionId, function ()
    local vehicleHash = util.joaat("adder")
    STREAMING.REQUEST_MODEL(vehicleHash)
    while not STREAMING.HAS_MODEL_LOADED(vehicleHash) do
		util.yield()
	end
    local pos = ENTITY.GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(PLAYER.PLAYER_PED_ID(), 0.0, 3.0, 0.0)
    VEHICLE.CREATE_VEHICLE(vehicleHash, pos.x, pos.y, pos.z, CAM.GET_GAMEPLAY_CAM_ROT(0).z, true, false)
end)

local isFreezed = false
local menuOptionFreeze = -1
menuOptionFreeze = gMenu.addOption(Sprite.new("RadialMenuDemo", "snowflake"), function ()
    ENTITY.FREEZE_ENTITY_POSITION(PLAYER.PLAYER_PED_ID(), not isFreezed)
    isFreezed = not isFreezed

    -- Lets make this option to change its own colour:

    local colour = isFreezed and {r = 1.0, g = 0, b = 0, a = 0.47} or {r = 1.0, g = 1.0, b = 1.0, a = 0.47}
    gMenu.setOptionBgColour(menuOptionFreeze, colour)
end)

gMenu.addOption(Sprite.new("RadialMenuDemo", "cloudy"), function ()
    local myPos = ENTITY.GET_ENTITY_COORDS(PLAYER.PLAYER_PED_ID())
    ENTITY.SET_ENTITY_COORDS(PLAYER.PLAYER_PED_ID(), myPos.x, myPos.y, myPos.z + 250.0)
end)


-- As I said, we can create multiple Menu instances.
-- Lets create another menu than opens with the same key:

gMenu2 = newMenu(gOpenKey)

-- And add options to that menu as well:

local optionId = gMenu2.addOption(nil, function ()
    util.toast("Hey, I'm an option of menu 2")
end)
gMenu2.setOptionOnFocusColour(optionId, {r = 0, g = 0.6, b = 0, a = 0.7})

-- version 2.0.0
-- The option's icon can be changed as well:

gMenu2.setOptionIcon(optionId, Sprite.new("RadialMenuDemo", "cloudy"))

-- An option with default values:
-- 1) Icon defaults to a question mark if none is passed.
-- 2) Function defaults to a function that does nothing.
-- These are default options just to see how they look like:

gMenu2.addOption()
gMenu2.addOption()
gMenu2.addOption()
gMenu2.addOption()
gMenu2.addOption()
gMenu2.addOption()
gMenu2.addOption()
gMenu2.addOption()
gMenu2.addOption()

-- At this point you already have two fully functional menus, it is pretty easy.
-- But what about customization? Am I able to manually open/close the menu or
-- focus some option if I want? The answer to those questions and some others is yes.

-- Let's suppose we want to create a settings list where the user is able to modify
-- characteristics of the menu:

local settings = menu.list(menu.my_root(), "Settings", {}, "", function ()

    -- Of course we'd like the menu to open when the users clicks this list,
    -- they should know what they're modifying. To do it we call the open() method:

    gMenu.open()

    -- (Notice that we're calling the open() method of gMenu so gMenu2 will remain closed)

    -- but the user would still be able to open/close the menu by clicking the open key,
    -- so we need to disable that.
    -- The menu has some flags that can be enabled/disabled to modify the overall behavior.
    -- To avoid the menu from opening/closing through the open key we enable MenuFlag_disableOpenKey

    gMenu.enableFlag(MenuFlag_disableOpenKey)

    -- We'd also like to disable reticle:

    gMenu.enableFlag(MenuFlag_disableReticle)

    --The menu moves when the mouse moves so options can be selected, but in this case
    --there's no need the user to select anything so we disable that too:

    gMenu.enableFlag(MenuFlag_freezePosition)

    -- To show what option the user is currently modifying we'd like to focus that option
    -- manually, but an option is auto unfocused when reticle is not in option's area.
    -- To prevent this from happening one can enable MenuFlag_noAutoUnfocus,
    -- which means any focused option needs to be manually unfocused.

    gMenu.enableFlag(MenuFlag_noAutoUnfocus)

    -- Lets also define a variable to know when the user is inside the settings list:

    gIsSettingsListOpened = true
end, function ()
    -- Once the user is done modifying the menu we close it:

    gMenu.close()

    -- and disable the flags we enabled:

    gMenu.disableFlag(MenuFlag_disableOpenKey)
    gMenu.disableFlag(MenuFlag_noAutoUnfocus)
    gMenu.disableFlag(MenuFlag_disableReticle)
    gMenu.disableFlag(MenuFlag_freezePosition)

    gIsSettingsListOpened = false
end)

-- Now lets create a list for each menu Option so they can be modified individually:

for optionId = 1, gMenu.options() do
    local optionSettings = menu.list(settings, "Option " .. optionId, {}, "")

    -- We need a way to know what's the option the user is going to modify:

    menu.on_focus(optionSettings, function () gCurrentlyFocusedMenuOption = optionId end)

    -- Now some options to change the Option's colour:

    -- version 2.0.0
    -- Both getOptionBgColour and getOptionOnFocusColour return tables with r, g, b, a and values
    -- between 0.0 and 1.0.

    local bgColour = gMenu.getOptionBgColour(optionId)

    menu.colour(optionSettings, "Background Colour", {"optbgcolour"}, "", bgColour, true, function (newColour)

        -- version 2.0.0
        -- In both setOptionBgColour and setOptionOnFocusColour colour is a table with r, g, b, a and values
        -- between 0.0 and 1.0.

        gMenu.setOptionBgColour(optionId, newColour)
    end)

    local onFocusColour = gMenu.getOptionOnFocusColour(optionId)
    menu.colour(optionSettings, "On Focus Colour", {"optonfocuscolour"}, "", onFocusColour, true, function (newColour)
        gMenu.setOptionOnFocusColour(optionId, newColour)
    end)
end

-- Now the main loop:

while true do
    -- It's a good idea to desable the open key:

    PAD.DISABLE_CONTROL_ACTION(0, gOpenKey, true)

    -- Now lets do what's left to complete the Settings list:

    if gIsSettingsListOpened then

        -- Now that we know the user is inside the Settings list, lets focus the Option
        -- they'd like to modify:

        for optionId = 1, gMenu.options(), 1 do
            if optionId == gCurrentlyFocusedMenuOption then

                -- To focus the Option we call focusOption method

                gMenu.focusOption(optionId)
            elseif gMenu.isOptionFocused(optionId) then

                -- Do you remember we enabled MenuFlag_noAutoUnfocus?
                -- Well, that means any focused Option is not auto unfoced so
                -- we need to do it manually

                gMenu.unfocusOption(optionId)
            end
        end
    end

    -- We can check if an Option was selected and get the selected option as well:

    -- isAnyOptionSelected() returns true if an option was selected
    -- and the open key is just released

    if gMenu.isAnyOptionSelected() then

        -- getSelectedOptionId() returns the selected option Id so
        -- make sure the value is valid

        local selectedOptionId = gMenu.getSelectedOptionId()
        util.toast("You selected option " .. selectedOptionId)
    end

    if gMenu2.isAnyOptionSelected() then
        util.toast("You selected an option of menu 2")
    end

    -- Finally, we must draw both menus:

    gMenu.draw()
    gMenu2.draw()


    util.yield()
end
